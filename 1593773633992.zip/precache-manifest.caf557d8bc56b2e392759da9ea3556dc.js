self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "25c9d6f2f09cd3cf360105c558da6b53",
    "url": "/index.html"
  },
  {
    "revision": "00ee9d344ddee4e6c1e1",
    "url": "/static/css/2.c3d8628e.chunk.css"
  },
  {
    "revision": "286e92e6a4abca9f3ee8",
    "url": "/static/css/main.b6794ccf.chunk.css"
  },
  {
    "revision": "00ee9d344ddee4e6c1e1",
    "url": "/static/js/2.fdeb7c51.chunk.js"
  },
  {
    "revision": "2b43e73fe3ff2e388163f0a96cd6568c",
    "url": "/static/js/2.fdeb7c51.chunk.js.LICENSE.txt"
  },
  {
    "revision": "286e92e6a4abca9f3ee8",
    "url": "/static/js/main.93ab4ffa.chunk.js"
  },
  {
    "revision": "2def77e0cfecb727feda",
    "url": "/static/js/runtime-main.c0b88796.js"
  },
  {
    "revision": "2e2f2c0777fef161c68bd4a48d1f0f10",
    "url": "/static/media/bebida.2e2f2c07.jpg"
  },
  {
    "revision": "a90f3b49821aab7dc62b36cd01914a3b",
    "url": "/static/media/cafe.a90f3b49.jpg"
  },
  {
    "revision": "052199899d8e7384f82e7a9bb07aaab8",
    "url": "/static/media/cerveceria.05219989.jpg"
  },
  {
    "revision": "f3f2d9b951f73e1871056e5761ee9603",
    "url": "/static/media/comida.f3f2d9b9.jpg"
  },
  {
    "revision": "a574b14d705374dafdd8674ee0f7c7c6",
    "url": "/static/media/farmacia.a574b14d.jpg"
  },
  {
    "revision": "802e5394a2e5639c8d8366bb7b7368b6",
    "url": "/static/media/helados.802e5394.jpg"
  },
  {
    "revision": "2b2cb7666e809da2e97e29dd34bf3194",
    "url": "/static/media/kiosko.2b2cb766.jpg"
  },
  {
    "revision": "a1041de78d5d025607344a8087c7a7e3",
    "url": "/static/media/otros.a1041de7.jpg"
  },
  {
    "revision": "245c52c95555bbb8ff02e9ec347823cb",
    "url": "/static/media/panaderia.245c52c9.jpg"
  },
  {
    "revision": "e4386ce68b7e9d9ec1f3cd8594358758",
    "url": "/static/media/saludable.e4386ce6.jpg"
  },
  {
    "revision": "012a440d2f3cd83dd8adfb15d69fa753",
    "url": "/static/media/verduleria.012a440d.jpg"
  }
]);